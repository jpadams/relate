#!/bin/sh
echo "greet: $CYPHERLITE_EXT_MESSAGE"
