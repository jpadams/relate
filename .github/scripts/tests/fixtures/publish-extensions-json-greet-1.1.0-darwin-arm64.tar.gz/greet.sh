#!/bin/sh
echo "greet $*"
